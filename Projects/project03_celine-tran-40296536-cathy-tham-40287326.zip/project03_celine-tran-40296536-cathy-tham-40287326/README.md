# Spin The Global Wheel
### Create an .env file:
- MONGODB_USER=name
- DATABASE_PASSWORD=password
- DATABASE_NAME=CART351

### Replace the uri with your MongoDB Atlas connection string
